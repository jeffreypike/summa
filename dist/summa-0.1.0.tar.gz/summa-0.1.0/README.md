# summa
Additive modelling package in Python
